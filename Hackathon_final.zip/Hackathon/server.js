const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const jwt = require('jsonwebtoken');
const userRoutes = require('./users');
const database = require('./database');
const app = express();
const port = 3000;
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));
app.get('/login.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'login.html'));
});
const authenticateJWT = (req, res, next) => {
    const token = req.headers['authorization']?.split(' ')[1];

    if (!token) {
        return res.status(401).json({ message: 'Unauthorized' });
    }

    jwt.verify(token, 'your_jwt_secret', (err, user) => {
        if (err) {
            return res.status(403).json({ message: 'Forbidden' });
        }

        req.user = user;
        next();
    });
};
app.use('/auth', userRoutes);
app.post('/add_account', (req, res) => {
    const { Account_holder_name, Account_number, balance, Account_type, Active_Loans, Account_opening_date } = req.body;
    const query = 'INSERT INTO account_details (Account_holder_name, Account_number, balance, Account_type, Active_Loans, Account_opening_date) VALUES (?, ?, ?, ?, ?, ?)';
    
    database.query(query, [Account_holder_name, Account_number, balance, Account_type, Active_Loans, Account_opening_date], (err, results) => {
        if (err) {
            console.error('Error inserting account details:', err);
            res.status(500).json({ success: false });
            return;
        }
        res.json({ success: true });
    });
});
app.post('/add_loan', (req, res) => {
    const { Account_number, Loan_name, Loan_amount, Duration, Loan_opening_date } = req.body;
    const query = 'INSERT INTO Loan_details (Account_number, Loan_name, Loan_amount, Duration, Loan_opening_date) VALUES (?, ?, ?, ?, ?)';
    
    database.query(query, [Account_number, Loan_name, Loan_amount, Duration, Loan_opening_date], (err, results) => {
        if (err) {
            console.error('Error inserting loan details:', err);
            res.status(500).json({ success: false });
            return;
        }
        res.json({ success: true });
    });
});
app.get('/Loan_details', (req, res) => {
    const query = 'SELECT * FROM Loan_details';
    database.query(query, (err, results) => {
        if (err) {
            console.error('Error fetching loan details:', err);
            res.status(500).send('Internal Server Error');
            return;
        }
        res.json(results);
    });
});

app.get('/account_details', (req, res) => {
    const query = 'SELECT * FROM account_details';
    database.query(query, (err, results) => {
        if (err) {
            console.error('Error fetching account details:', err);
            res.status(500).send('Internal Server Error');
            return;
        }
        res.json(results);
    });
})
app.get('/account_details/:account_number', (req, res) => {
    const accountNumber = req.params.account_number;
    const query = 'SELECT * FROM account_details WHERE Account_number = ?';

    database.query(query, [accountNumber], (err, results) => {
        if (err) {
            console.error('Error fetching account details:', err);
            res.status(500).send('Internal Server Error');
            return;
        }
        res.json(results);
    });
});
app.put('/update_account/:Account_number', (req, res) => {
    const Account_number = req.params.Account_number;
    const { holderName, balance, accountType, activeLoans, accountOpeningDate } = req.body;
    const query = 'UPDATE account_details SET Account_holder_name = ?, balance = ?, Account_type = ?, Active_Loans = ?, Account_opening_date = ? WHERE Account_number = ?';
    
    database.query(query, [holderName, balance, accountType, activeLoans, accountOpeningDate,Account_number], (err, results) => {
        if (err) {
            console.error('Error updating account details:', err);
            res.status(500).json({ success: false });
            return;
        }
        res.json({ success: true });
    });
});
app.delete('/delete_account/:Account_number', (req, res) => {
    const Account_number = req.params.Account_number;
    const query = 'DELETE FROM account_details WHERE Account_number = ?';
    
    database.query(query, [Account_number], (err, results) => {
        if (err) {
            console.error('Error deleting account details:', err);
            res.status(500).json({ success: false });
            return;
        }
        res.json({ success: true });
    });
});

app.get('/Loan_details/:Account_number', (req, res) => {
    const accountNumber = req.params.Account_number;
    const query = 'SELECT * FROM Loan_details WHERE Account_number = ?';

    database.query(query, [accountNumber], (err, results) => {
        if (err) {
            console.error('Error fetching account details:', err);
            res.status(500).send('Internal Server Error');
            return;
        }
        res.json(results);
    });
});
app.put('/update_loan/:Account_number', (req, res) => {
    const Account_number = req.params.Account_number;
    const { loanName, loanAmount, duration, loanOpeningDate } = req.body;
    const query = 'UPDATE Loan_details SET Loan_name = ?, Loan_amount = ?, Duration = ?, Loan_opening_date = ? WHERE Account_number = ?';
    
    database.query(query, [loanName, loanAmount, duration, loanOpeningDate, Account_number], (err, results) => {
        if (err) {
            console.error('Error updating loan details:', err);
            res.status(500).json({ success: false });
            return;
        }
        res.json({ success: true });
    });
});
app.delete('/delete_loan/:Loan_id', (req, res) => {
    const Loan_id = req.params.Loan_id;
    const query = 'DELETE FROM Loan_details WHERE Loan_id = ?';
    
    database.query(query, [Loan_id], (err, results) => {
        if (err) {
            console.error('Error deleting loan details:', err);
            res.status(500).json({ success: false });
            return;
        }
        res.json({ success: true });
    });
});
app.get('/index.html', authenticateJWT, (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});
app.get('/addAccount.html', authenticateJWT, (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'addAccount.html'));
});

app.get('/addLoan.html', authenticateJWT, (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'addLoan.html'));
});

app.get('/accounts.html', authenticateJWT, (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'accounts.html'));
});

app.get('/loan.html', authenticateJWT, (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'loan.html'));
});

// Start the server
app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}/login.html`);
});
