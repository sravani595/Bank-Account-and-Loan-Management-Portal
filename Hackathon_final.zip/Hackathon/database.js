const mysql= require('mysql2');
const database=mysql.createConnection({
    host: 'localhost',
    port: 3306,
    user: 'root',
    password: '#Sravani@94***',
    database: 'sravani'
});
database.connect((err)=>{
    if(err){
        console.log("Fail to connect Database : ",err);
        return;
    };
    console.log("succussfully connected to Database.");
});
module.exports=database;