He I created a website
In this we can add account, apply loan, view all account details and view all loans.
index.html having 4 buttons: Add Account, apply Loan, Accounts, Loan Details.
when we click on the accounts button it shows the details of all the accounts in tabular having 2 buttons call edit and delete.
when we click on the Loan Details  button it shows the loan Details in tabular having 2 buttons call edit and delete.
I need to add authentication for this web page.
