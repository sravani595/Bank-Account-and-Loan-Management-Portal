USE database sravani;

create table account_details(
    Account_holder_name varchar(30),
    Account_number int PRIMARY KEY,
    balance int,
    Account_type varchar(30),
    Active_Loans varchar(30),
    Account_opening_date date
);

INSERT INTO account_details(Account_holder_name,Account_number,balance,Account_type,Active_Loans,Account_opening_date)
VALUES
('Joe',1239873,200000,'Savings','No','2015-06-23'),
('sam',7756432,500000,'Current','Yes','2014-03-11')

create table Loan_details(
    Account_number int,
    Loan_name varchar(30),
    Loan_amount int,
    Duration varchar(30),
    Loan_opening_date date,
    FOREIGN KEY (Account_number) REFERENCES account_details(Account_number)
);
INSERT INTO Loan_details(Account_number,Loan_name,Loan_amount,Duration,Loan_opening_date)
VALUES
(7756432,"Home",800000,"5 years",'2021-08-4'),
